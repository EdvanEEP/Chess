var annotated_dup =
[
    [ "chessBoard", "classchess_board.html", "classchess_board" ],
    [ "Chessman", "class_chessman.html", "class_chessman" ],
    [ "gameLogic", "classgame_logic.html", "classgame_logic" ],
    [ "Textures", "class_textures.html", null ]
];