var class_board =
[
    [ "Board", "class_board.html#a412c4a7387662a210c5360ee9bae3132", null ],
    [ "draw", "class_board.html#ab75be2f74cebd4ba94ad218cadc88ce9", null ],
    [ "load", "class_board.html#a1facd354208fa681a394bfc767703715", null ],
    [ "board", "class_board.html#a5d481027a16e803be557daca163b4d8c", null ]
];