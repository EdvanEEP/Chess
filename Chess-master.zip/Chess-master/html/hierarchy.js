var hierarchy =
[
    [ "sf::Drawable", null, [
      [ "Chessman", "class_chessman.html", null ],
      [ "chessBoard", "classchess_board.html", null ],
      [ "gameLogic", "classgame_logic.html", null ]
    ] ],
    [ "Textures", "class_textures.html", null ]
];