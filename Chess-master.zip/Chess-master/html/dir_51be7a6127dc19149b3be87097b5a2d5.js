var dir_51be7a6127dc19149b3be87097b5a2d5 =
[
    [ "chessBoard.cpp", "chess_board_8cpp.html", null ],
    [ "chessBoard.h", "chess_board_8h.html", "chess_board_8h" ],
    [ "chessman.cpp", "chessman_8cpp.html", null ],
    [ "chessman.h", "chessman_8h.html", "chessman_8h" ],
    [ "gameLogic.cpp", "game_logic_8cpp.html", null ],
    [ "gameLogic.h", "game_logic_8h.html", "game_logic_8h" ],
    [ "mainClass.cpp", "main_class_8cpp.html", "main_class_8cpp" ],
    [ "Textures.cpp", "_textures_8cpp.html", null ],
    [ "Textures.h", "_textures_8h.html", "_textures_8h" ]
];