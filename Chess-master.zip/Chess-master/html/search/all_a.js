var searchData=
[
  ['restart_0',['restart',['../classgame_logic.html#acebfeba01a67c38323154d315eac776e',1,'gameLogic']]]
];
