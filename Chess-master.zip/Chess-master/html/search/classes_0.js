var searchData=
[
  ['chessboard_0',['chessBoard',['../classchess_board.html',1,'']]],
  ['chessman_1',['Chessman',['../class_chessman.html',1,'']]]
];
