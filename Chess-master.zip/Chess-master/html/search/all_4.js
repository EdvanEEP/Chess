var searchData=
[
  ['font_0',['font',['../classgame_logic.html#a46c5cacf0700d2d275c0850b9b5a505c',1,'gameLogic']]]
];
