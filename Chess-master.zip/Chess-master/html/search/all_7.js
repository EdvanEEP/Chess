var searchData=
[
  ['load_0',['load',['../classchess_board.html#ad477c210e1d160eb9995f96aa379c60a',1,'chessBoard']]]
];
