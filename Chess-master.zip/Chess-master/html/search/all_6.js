var searchData=
[
  ['inforestart_0',['infoRestart',['../classgame_logic.html#a547aeda0f99009171cbbdf8e6a6b92b7',1,'gameLogic']]]
];
