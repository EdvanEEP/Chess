var searchData=
[
  ['whitepieces_0',['whitePieces',['../class_chess_game.html#aedb893fa100fb26cab8306ee17034cf9',1,'ChessGame']]]
];
