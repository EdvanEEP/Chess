var searchData=
[
  ['dangermoves_0',['dangerMoves',['../class_chessman.html#a2623ea202049a22256c0db19dbdc6a4a',1,'Chessman']]]
];
