var searchData=
[
  ['chess_5fboard_0',['chess_board',['../classchess_board.html#a31d0c0b738cf7d090edfa838e5be6312',1,'chessBoard']]]
];
