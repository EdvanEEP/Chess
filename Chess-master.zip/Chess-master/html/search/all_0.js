var searchData=
[
  ['beyaz_5fat_0',['beyaz_at',['../class_textures.html#a7dc181868b168298c721c841c8e87776',1,'Textures']]],
  ['beyaz_5ffil_1',['beyaz_fil',['../class_textures.html#a3fcf472030a2b9a50d2b71a686e6f6ec',1,'Textures']]],
  ['beyaz_5fkale_2',['beyaz_kale',['../class_textures.html#a505b3ad0611dafeec0fc84e4dbb7587a',1,'Textures']]],
  ['beyaz_5fpiyon_3',['beyaz_piyon',['../class_textures.html#a604449e46993241afe94dfa602a3c393',1,'Textures']]],
  ['beyaz_5fsah_4',['beyaz_sah',['../class_textures.html#ab43f0f74c022fcc40b19d7ba02b4d790',1,'Textures']]],
  ['beyaz_5fvezir_5',['beyaz_vezir',['../class_textures.html#a108d830de55f839ead6eaa393fe35d49',1,'Textures']]],
  ['board_6',['board',['../classgame_logic.html#a664c1247aed5a18b504f7e371e1a6e62',1,'gameLogic']]]
];
