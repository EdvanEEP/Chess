var searchData=
[
  ['updateinfo_0',['updateInfo',['../class_chess_game.html#a6ddd05254bb51955d498650bc29f0385',1,'ChessGame']]]
];
