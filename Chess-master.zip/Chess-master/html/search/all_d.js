var searchData=
[
  ['updateinfo_0',['updateInfo',['../classgame_logic.html#a82cbffa0a6959afe4db7014f3cfbd7b1',1,'gameLogic']]]
];
