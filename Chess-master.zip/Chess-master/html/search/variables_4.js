var searchData=
[
  ['gameover_0',['gameOver',['../classgame_logic.html#a3b749d53e18beffabe8f5511737c6af9',1,'gameLogic']]]
];
