var searchData=
[
  ['textexit_0',['textExit',['../classgame_logic.html#aade0c223ac3a9874e04d104cec279356',1,'gameLogic']]],
  ['textlastmove_1',['textLastMove',['../classgame_logic.html#a6379a398beb40023d3c3843ad18145a8',1,'gameLogic']]],
  ['textrestart_2',['textRestart',['../classgame_logic.html#a3c841eb37f6c84963d14fdf05856600d',1,'gameLogic']]],
  ['textsituation_3',['textSituation',['../classgame_logic.html#ad8b91c8dd8ee0fec87c85c66baad9da6',1,'gameLogic']]],
  ['textturn_4',['textTurn',['../classgame_logic.html#abc78f9ed34db4de7d11b4ce6cbf201ef',1,'gameLogic']]],
  ['turn_5',['turn',['../classgame_logic.html#a69914b29d92d1103122844f6ceae0845',1,'gameLogic']]]
];
