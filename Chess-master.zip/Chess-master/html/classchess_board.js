var classchess_board =
[
    [ "chessBoard", "classchess_board.html#a6b267b2aa9718180f10689ad3c7a396a", null ],
    [ "draw", "classchess_board.html#aece0ca006f8fe57119319c28d0ce06aa", null ],
    [ "load", "classchess_board.html#ad477c210e1d160eb9995f96aa379c60a", null ],
    [ "chess_board", "classchess_board.html#a31d0c0b738cf7d090edfa838e5be6312", null ]
];